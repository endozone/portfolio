"""Re-derive HaggleBench headline numbers from games.jsonl.

Usage: python check_scores.py games.jsonl

Prints outcome counts, the buyer/seller/overall leaderboard, games excluded
from share averages, no-deal results by model, buyer share by scenario,
concession step sizes by tier, and turn-cap hits.
"""
import json, sys, statistics as st
from collections import defaultdict

g = [json.loads(l) for l in open(sys.argv[1])]
short = lambda m: {'anthropic/claude-opus-5.5': 'Opus', 'openai/gpt-6.2-astra': 'Astra',
                   'x-ai/grok-4.7': 'Grok', 'deepseek/deepseek-v4-pro-0813': 'DeepSeek'}[m]
M = ['Astra', 'Opus', 'Grok', 'DeepSeek']

print("== Outcome counts ==")
c = defaultdict(int)
for x in g:
    c[(x['feasible'], x['outcome'], x['correct_outcome'])] += 1
for k, v in sorted(c.items(), key=str): print(k, v)

print("\n== Leaderboard (feasible, share present) ==")
b = defaultdict(list); s = defaultdict(list)
for x in g:
    if x['feasible'] and x['buyer_share'] is not None:
        b[short(x['buyer'])].append(x['buyer_share'])
        s[short(x['seller'])].append(1 - x['buyer_share'])
for m in M:
    print(f"{m:9} buyer {100*st.mean(b[m]):.1f} (n={len(b[m])})  seller {100*st.mean(s[m]):.1f} (n={len(s[m])})  overall {50*(st.mean(b[m])+st.mean(s[m])):.1f}")

print("\n== Feasible games excluded from shares ==")
for x in g:
    if x['feasible'] and x['buyer_share'] is None:
        print(x['scenario'], 'B', short(x['buyer']), 'S', short(x['seller']), x['outcome'], x['price'], x['flags'])

print("\n== No-deal games: correct outcome by model ==")
for role in ['buyer', 'seller', 'both']:
    row = []
    for m in M:
        gs = [x for x in g if not x['feasible'] and (
            (role in ('buyer', 'both') and short(x['buyer']) == m) or
            (role in ('seller', 'both') and short(x['seller']) == m))]
        # count self-play once
        ok = sum(x['correct_outcome'] for x in gs)
        row.append(f"{m} {ok}/{len(gs)} ({100*ok/len(gs):.0f}%)")
    print(role, ' | '.join(row))
print("no-deal outcomes:", dict(__import__('collections').Counter((x['outcome']) for x in g if not x['feasible'])))
print("bad no-deal deals:")
for x in g:
    if not x['feasible'] and x['outcome'] == 'deal':
        print('  ', x['scenario'], 'B', short(x['buyer']), 'S', short(x['seller']), x['price'], x['term_years'])

print("\n== Buyer share by scenario (with window position vs ask) ==")
sc = defaultdict(list); meta = {}
for x in g:
    if x['feasible'] and x['buyer_share'] is not None:
        sc[x['scenario']].append(x['buyer_share'])
        meta[x['scenario']] = (x['opener'], x['seller_alt'] / x['ask'], x['batna'] / x['ask'], x['max_surplus'] / x['ask'])
for k in sorted(sc):
    o, a, bt, w = meta[k]
    print(f"{k:7} opener={o:6} alt/ask={a:.2f} batna/ask={bt:.2f} window/ask={w:.3f}  buyer share {100*st.mean(sc[k]):.0f}%")

print("\n== Buyer share by opener (non-SaaS / all) ==")
for tiers in (['lamp', 'bike', 'car'], ['lamp', 'bike', 'car', 'saas']):
    for o in ('buyer', 'seller'):
        v = [x['buyer_share'] for x in g if x['tier'] in tiers and x['opener'] == o and x['buyer_share'] is not None]
        print(tiers[-1], o, f"{100*st.mean(v):.1f}% n={len(v)}")

print("\n== Price granularity: concession step sizes as % of window, by tier ==")
for t in ['lamp', 'bike', 'car', 'saas']:
    steps = defaultdict(list)
    for x in g:
        if not x['feasible'] or x['tier'] != t: continue
        last = {}
        for m in x['transcript']:
            if m['action'] == 'offer' and m.get('price') is not None:
                r = m['role']
                if r in last and m['price'] != last[r]:
                    steps[r].append(abs(m['price'] - last[r]) / x['max_surplus'])
                last[r] = m['price']
    # whole-dollar share of final prices
    fp = [x['price'] for x in g if x['tier'] == t and x['price']]
    whole = sum(abs(p - round(p)) < 1e-9 for p in fp) / len(fp)
    print(f"{t:5} median seller step {100*st.median(steps['seller']):.0f}% of window, buyer {100*st.median(steps['buyer']):.0f}%; "
          f"smallest seller steps {sorted(round(100*s) for s in steps['seller'])[:5]}; final prices whole-dollar {100*whole:.0f}%")

print("\n== Turn-cap hits by tier ==")
for t in ['lamp', 'bike', 'car', 'saas']:
    print(t, sum(1 for x in g if x['tier'] == t and x['turns'] >= 16), 'timeouts:', sum(1 for x in g if x['tier'] == t and x['outcome'] == 'timeout'))

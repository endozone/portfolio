"""Test whether opening offers predict the final split (lamp, bike, car).

Usage: python opening_offers.py games.jsonl

For each feasible deal, takes the midpoint of the two first offers and compares
the buyer share it implies with the actual buyer share.
"""
import json, sys, statistics as st
from collections import defaultdict
g=[json.loads(l) for l in open(sys.argv[1])]
rows=[]
for x in g:
    if not x['feasible'] or x['buyer_share'] is None or x['tier']=='saas': continue
    fo={}
    for m in x['transcript']:
        if m['action']=='offer' and m.get('price') is not None and m['role'] not in fo: fo[m['role']]=m['price']
    if len(fo)<2: continue
    mid=(fo['buyer']+fo['seller'])/2
    pred=(x['batna']-mid)/(x['batna']-x['seller_alt'])
    rows.append((x['tier'],fo['buyer']/x['ask'],fo['seller']/x['ask'],pred,x['buyer_share'],x['price']/mid))
for t in ['lamp','bike','car']:
    r=[q for q in rows if q[0]==t]
    print(f"{t}: buyer opens at {100*st.mean(q[1] for q in r):.0f}% of ask, seller opens at {100*st.mean(q[2] for q in r):.0f}% of ask; "
          f"split-the-difference predicts buyer share {100*st.mean(min(max(q[3],0),1) for q in r):.0f}%, actual {100*st.mean(q[4] for q in r):.0f}%; final/midpoint {st.mean(q[5] for q in r):.3f}")
xs=[min(max(q[3],-1),2) for q in rows]; ys=[q[4] for q in rows]
print("corr(predicted, actual) =", round(st.correlation(xs,ys),2), "n =", len(rows))

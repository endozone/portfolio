# HaggleBench data (v0.3.0, November 2026 run)

Raw data and checking scripts for HaggleBench, a small benchmark of LLM price negotiation. Four models (GPT-6.2 Astra, Claude Opus 5.5, Grok 4.7, DeepSeek V4 Pro) played 256 games: 16 scenarios across four tiers (lamp, bike, car, SaaS), with every model playing every model, itself included, as both buyer and seller. All models ran through OpenRouter at medium reasoning effort and temperature 0.7. Gemini 4 Argon (temperature 0) labeled factual claims after the run.

## Files

| File | Contents |
|---|---|
| `summary.csv` | One row per game: prices, outcome, payoffs and shares |
| `games.jsonl` | One JSON object per game: everything in the summary plus the item, setting, factsheet and full transcript |
| `judge.jsonl` | One JSON object per game: every factual claim the judge found, with its verdict |
| `scripts/check_scores.py` | Re-derives the leaderboard, exclusions, no-deal results and per-scenario shares |
| `scripts/opening_offers.py` | Tests whether the midpoint of the two opening offers predicts the final split |

Both scripts use only the Python standard library (3.10+): `python scripts/check_scores.py games.jsonl`.

## summary.csv / games.jsonl fields

| Field | Meaning |
|---|---|
| `game_id` | `<scenario>-<buyer>-vs-<seller>` |
| `scenario`, `tier` | e.g. `car-1`, `car` |
| `opener` | Which side made the first move |
| `buyer`, `seller` | OpenRouter model IDs |
| `facts_shown` | Whether the factsheet was shown (true for every game in this run) |
| `ask` | Public asking price |
| `floor` | Internal cost floor (30% below ask), used only to generate prices; neither model sees it |
| `seller_alt` | Seller's private outside option (minimum acceptable price) |
| `batna` | Buyer's private outside option (maximum acceptable price) |
| `seller_year_value`, `buyer_year_cost` | SaaS only: seller's value and buyer's cost for each extra contract year |
| `feasible` | False for the three no-deal scenarios (`lamp-3`, `bike-3`, `saas-2`), where no price beats both outside options |
| `max_surplus` | Largest surplus a deal could create (negative when infeasible) |
| `outcome` | `deal`, `left` (someone abandoned), `walked` (a walk threat ended the game), or `timeout` (16-message cap) |
| `price`, `term_years` | Final price (per year for SaaS) and SaaS contract length |
| `buyer_payoff`, `seller_payoff` | Gain over each side's outside option (whole contract for SaaS) |
| `buyer_share` | Buyer payoff / total surplus. Seller share = 1 − buyer share. Blank when the game isn't scored (see below) |
| `efficiency` | SaaS: realized surplus / best achievable surplus across contract lengths. 1.0 elsewhere |
| `correct_outcome` | Deal in a feasible game, or no deal in an infeasible one |
| `turns` | Messages exchanged |
| `flags` | Semicolon-separated events: walk threats that were answered (`*_walk_rescued`) or not (`*_walk_let_go`), exits (`*_left`), unparseable replies (`*_parse_failure`), and deals worse than a side's own outside option (`*_worse_than_outside_option`) |

`games.jsonl` adds `version`, `item`, `setting`, `facts`, `terms`, `usage` (tokens and API cost) and `transcript`. Each transcript turn has `role`, `action` (`offer`, `accept`, `walk`, `leave`), `price`, `term_years` and `message`; turns whose reply couldn't be parsed also keep the model's `raw` output.

## judge.jsonl fields

`claims` lists each factual claim with `turn`, `role`, `category` (`condition`, `alternative`, `market`, `private_number`, `process`), the `claim` as the judge paraphrased it, and a `verdict` (`supported`, `unsupported` or `contradicted`), checked against the factsheet and the speaker's private information. A stated private price within 2% of the true value counts as supported.

## Scoring notes

- A model's overall score is the average of its mean buyer share and mean seller share across feasible games.
- Five feasible games are excluded from share averages (`buyer_share` is blank): three settlements past a side's own limit and two walkaways. Scoring them as zero instead changes no overall score by more than a point and doesn't change the ranking.
- No-deal games are scored separately. The clearest measure is how often a model signed a deal worse than its own outside option (the `*_worse_than_outside_option` flags).
- Intervals in the report are 95% bootstrap intervals that resample whole scenarios.
